// src/services/storage.ts
var TABS_KEY = "tabs";
var BINS_KEY = "bins";
async function getStashedTabs() {
  const result = await chrome.storage.local.get(TABS_KEY);
  return result[TABS_KEY] ?? [];
}
async function saveStashedTabs(tabs) {
  await chrome.storage.local.set({ [TABS_KEY]: tabs });
}
async function getBins() {
  const result = await chrome.storage.local.get(BINS_KEY);
  return result[BINS_KEY] ?? [];
}

// src/services/aiProvider.ts
var MODEL = "claude-haiku-4-5";
var API_URL = "https://api.anthropic.com/v1/messages";
function getApiKey() {
  const key = "";
  return typeof key === "string" && key.trim() ? key.trim() : null;
}
async function requestSort(req) {
  const key = getApiKey();
  if (!key) throw new Error("No API key configured");
  const system = "You organize browser tabs into the user's existing bins (folders) by topic. For each tab, pick the single existing bin it best fits. Only assign a tab to a bin when it clearly belongs there; if no bin is a good fit, use -1. Never force a weak match.";
  const binLines = req.bins.map((b) => `${b.index}: ${b.name}`).join("\n");
  const tabLines = req.tabs.map((t) => `${t.index}: "${t.name}" (${t.host})`).join("\n");
  const userMsg = `Existing bins:
${binLines}

Tabs to sort:
${tabLines}

Return one assignment for every tab.`;
  const body = {
    model: MODEL,
    max_tokens: 2048,
    system,
    messages: [{ role: "user", content: userMsg }],
    tools: [
      {
        name: "submit_assignments",
        description: "Record which existing bin each tab belongs to.",
        input_schema: {
          type: "object",
          properties: {
            assignments: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  tab: { type: "integer", description: "the tab index" },
                  bin: {
                    type: "integer",
                    description: "the best-fitting existing bin index, or -1 if none fit"
                  }
                },
                required: ["tab", "bin"]
              }
            }
          },
          required: ["assignments"]
        }
      }
    ],
    tool_choice: { type: "tool", name: "submit_assignments" }
  };
  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
      // Required to call the API from a browser/extension context.
      "anthropic-dangerous-direct-browser-access": "true"
    },
    body: JSON.stringify(body)
  });
  if (!res.ok) throw new Error(`AI request failed: ${res.status}`);
  const data = await res.json();
  const toolUse = (data.content ?? []).find((b) => b.type === "tool_use");
  const assignments = toolUse?.input?.assignments;
  if (!Array.isArray(assignments)) throw new Error("Malformed AI response");
  return assignments;
}

// src/services/aiSort.ts
function host(url) {
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}
async function sortIntoExistingBins(tabs, bins, sort = requestSort) {
  if (tabs.length === 0 || bins.length === 0) {
    return { placements: [], leftovers: tabs, succeeded: true };
  }
  try {
    const req = {
      tabs: tabs.map((t, i) => ({ index: i, name: t.name, host: host(t.url) })),
      bins: bins.map((b, i) => ({ index: i, name: b.name }))
    };
    const assignments = await sort(req);
    const binOf = /* @__PURE__ */ new Map();
    for (const a of assignments) {
      if (a.tab >= 0 && a.tab < tabs.length && a.bin >= 0 && a.bin < bins.length) {
        binOf.set(a.tab, bins[a.bin].id);
      }
    }
    const placements = [];
    const leftovers = [];
    tabs.forEach((tab, i) => {
      const binId = binOf.get(i);
      if (binId) placements.push({ tab, binId });
      else leftovers.push(tab);
    });
    return { placements, leftovers, succeeded: true };
  } catch {
    return { placements: [], leftovers: tabs, succeeded: false };
  }
}

// src/services/operations.ts
var sorting = null;
function aiSortPendingTabs() {
  if (!sorting) {
    sorting = doAiSortPendingTabs().finally(() => {
      sorting = null;
    });
  }
  return sorting;
}
async function doAiSortPendingTabs() {
  const tabs = await getStashedTabs();
  const pending = tabs.filter((t) => t.needsSort);
  if (pending.length === 0) return;
  const bins = await getBins();
  if (bins.length === 0) {
    await saveStashedTabs(tabs.map((t) => t.needsSort ? { ...t, needsSort: false } : t));
    return;
  }
  const { placements, succeeded } = await sortIntoExistingBins(pending, bins);
  if (!succeeded) return;
  const binOf = new Map(placements.map((p) => [p.tab.id, p.binId]));
  await saveStashedTabs(
    tabs.map(
      (t) => t.needsSort ? { ...t, binId: binOf.get(t.id) ?? t.binId, needsSort: false } : t
    )
  );
}

// src/service-worker.ts
chrome.runtime.onStartup.addListener(() => {
  void aiSortPendingTabs();
});
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type !== "AI_SORT_PENDING") return;
  aiSortPendingTabs().finally(() => sendResponse({ done: true }));
  return true;
});
